# Transformer Models Collection

## Instalation

- On a python 3.7+ virtual environment:
```pip install -r requirements.txt```


## Training and Running
```python -m src.biconditional.train```  
```python -m src.vanilla.train```
